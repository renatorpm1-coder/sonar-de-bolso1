# Sonar de Bolso

App Android que transforma o celular num sonar acústico: o alto-falante emite um pulso curto (chirp), o microfone capta o eco e o app calcula a distância até o obstáculo.

## Como instalar

1. Abra a aba **Releases** deste repositório no celular.
2. Baixe o `sonar-de-bolso.apk` da versão mais recente.
3. Toque no arquivo baixado e permita a instalação de "fontes desconhecidas" quando o Android pedir.
4. Abra o app e permita o uso do microfone.

O APK é gerado automaticamente pelo GitHub Actions a cada alteração na branch `main`.

## Como usar

- Volume no máximo, ambiente silencioso.
- Toque em **Calibrar** apontando o celular para um espaço aberto.
- Aponte a parte de baixo do celular para uma parede entre 0,5 e 3 m e toque em **Ping** ou **Varredura**.

## Estrutura

- `app/src/main/assets/index.html` — o sonar (Web Audio + filtro casado)
- `app/src/main/java/br/sonardebolso/MainActivity.java` — WebView que libera o microfone
- `.github/workflows/build.yml` — compila o APK e publica em Releases
